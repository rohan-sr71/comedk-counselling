
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		#y1
		{
			float: left;
		}
		
	</style>
	<style>
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

</head>
<body>
		<div class="heading">
    <img src="header.jpeg" width="100%" height="100px">
  </div>
 
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div>
      <ul class="nav navbar-nav">
        <li ><a href="home.html">Home</a></li>
                 <li class="active" ><a href="collegedetails.html">College Details</a></li>
                <li ><a href="collegefee.html">College fee </a></li>
                <li ><a href="contactcomedk.html">Contact us</a></li>
                <li><a href="aboutcomedk.html">About us</a></li>
                 <li><a href="preferences.html">Preferences</a></li>
                 <li ><a href="seat.html">Seat Availability</a></li>
                 <li><a href="index.html">Logout</a></li>
          </ul>
      </div>
  </div>
</nav>

</div>
</body>
</html>
<?php
$coll= $_GET["ref"];
include("conn.php");
$sql="CALL getdata('$coll')";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
echo "<table border='1' id=customers>
<tr>
<th>COLLEGE NAME</th>
<th>COLLEGE ID</th>
<th>PHONE NUMBER</th>
<th>ADDRESS</th>
<th>ESTABLISH DATE</th>
<th>AFFILIATION</th>
<th>WEBSITE</th>
</tr>";
echo "<tr>"; 

    echo "<td>" . $row['COLLEGE_NAME'] . "</td>";
    echo"<td>". $row['COLLEGE_ID']."</td>";
    echo"<td>". $row['PHONE_NO']."</td>";
    echo"<td>". $row['ADDRESS'] ."</td>";
    echo"<td>". $row['ESTABLISHING_YEAR'] ."</td>";
    echo"<td>". $row['AFFILIATION'] ."</td>";
    echo"<td>". $row['WEBSITE'] ."</td>";

echo "</table>";

 ?>
<?php 
$conn= new mysqli("localhost","root","","comed-k");
 ?>
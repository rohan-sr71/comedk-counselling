<?php 
$name=filter_input(INPUT_POST,'name');
$dob=filter_input(INPUT_POST,'dob');
$age=filter_input(INPUT_POST,'age');
$roll=filter_input(INPUT_POST,'rollno');
$rank=filter_input(INPUT_POST,'rank');
$marks=filter_input(INPUT_POST,'marks');
$email=filter_input(INPUT_POST,'email');
$phone=filter_input(INPUT_POST,'mobileno');
$state=filter_input(INPUT_POST,'state');
$city=filter_input(INPUT_POST,'city');
$pass=filter_input(INPUT_POST,'psw');
$rpass=filter_input(INPUT_POST,'rpass');
include("conn.php");
if($pass==$rpass){
$sql="INSERT INTO sign_up
VALUES ('$name','$dob','$age','$roll','$rank','$marks','$email','$phone','$state','$city','$pass')";
if($conn->query($sql))
{
	echo "new record inserted";
	header("location:home.html");
}
else
{
	echo "error";
}
}
else{
echo "password not matching";
}
?>
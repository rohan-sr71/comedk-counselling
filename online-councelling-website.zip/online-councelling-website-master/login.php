<?php 
$name=filter_input(INPUT_POST,'username');
$pass=filter_input(INPUT_POST,'Password');
$host="localhost";
$dbuser="root";
$dbpass="";
$dbname="comedk07";
$conn=new mysqli ($host,$dbuser,$dbpass,$dbname);
$sql="SELECT * FROM login WHERE USERNAME= '$name' AND PASSWORD= '$pass'";
$sql1=mysqli_query($conn, $sql);
$result= mysqli_num_rows($sql1);
if($result==1)
{
	echo "insert successful";
	include("aboutcomedk.html");

 }
 else
 {
 	echo "error";
 }
?>
-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2018 at 07:57 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comed-k`
--

-- --------------------------------------------------------

--
-- Table structure for table `college_details`
--

CREATE TABLE `college_details` (
  `COLLEGE_NAME` varchar(50) NOT NULL,
  `COLLEGE_ID` varchar(10) NOT NULL,
  `PHONE_NO` varchar(20) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `ESTABLISHING_YEAR` int(11) NOT NULL,
  `AFFILIATION` varchar(40) NOT NULL,
  `WEBSITE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_details`
--

INSERT INTO `college_details` (`COLLEGE_NAME`, `COLLEGE_ID`, `PHONE_NO`, `ADDRESS`, `ESTABLISHING_YEAR`, `AFFILIATION`, `WEBSITE`) VALUES
('ACHARAYA INSTITUTE OF TECHNOLOGY', 'AY', '080-28396011', 'Acharya Dr. Sarvepalli\r\nRadhakrishnan Road\r\nAcharya PO, Soladevanahalli\r\nBangalore-560 107, India', 2000, 'VTU', 'https://www.acharya.ac.in/acharya-institute-of-technology'),
('BANGALORE INSTITUTE OF TECHNOLOGY', 'BI', '080-26615865', 'BANGALORE INSTITUTE OF TECHNOLOGY\r\nK.R. ROAD ; V V PURAM\r\nBANGALORE-560004', 1979, 'VTU', 'http://bit-bangalore.edu.in/'),
(' BMS COLLEGE OF ENGINEERING', 'BM', '080-22427424', 'Bull Temple Road, Basavanagudi, Bengaluru, Karnataka 560019', 1946, 'AUTONOMOUS', 'http://bmsce.in/'),
('C.M.R INSTITUTE OF TECHNOLOGY ', 'CR', '080-28524477', '132 AECS Layout\r\nITPL Main Road\r\nKundalahalli\r\nBangalore 560037, India', 2000, 'VTU', 'www.cmrit.ac.in'),
('GLOBAL ACADEMY OF TECHNOLOGY', 'GA', '080-28603158	', 'Ideal Homes Township, Mysore Rd, Aditya Layout, RR Nagar, Bengaluru, Karnataka 560098', 2001, 'VTU', 'http://www.gat.ac.in'),
('SJB INSTITUTE OF TECHNOLOGY', 'JB', '080-28603651', '#67, BGS Health & Education City,\r\nDr. Vishnuvardhan Road, Kengeri, Bengaluru – 560060.', 2001, 'VTU', 'http://sjbit.edu.in/'),
('JSS ACADEMY OF TECHNICIAL EDUCATION', 'JS', '080-28603425	', 'JSS Academy of Technical Education, Bengaluru\r\nJSSATE-B Campus,\r\nUttarahalli-Kengeri Road, Bengaluru', 1997, 'VTU', 'http://jssateb.ac.in/'),
('K.S.INSTITUTE OF TECHNOLOGY', 'KS', '080-	28435724', 'K.S. Institute of Technology\r\nNo.14, Raghuvanahalli, Kanakapura Main Road, Bengaluru - 560109', 1952, 'VTU', 'http://www.ksit.ac.in'),
('M.S.RAMAIAH INSTITUTE OF TECHNIOLOGY', 'MS', '080-23600822	', 'MSRIT Post, M S Ramaiah Nagar, MSR Nagar, Bengaluru, Karnataka 560054', 1962, 'AUTONOMOUS', 'http://www.msrit.edu/'),
('RNS INSTITUTE OF TECHNOLOGY', 'RN', '080-28611880', 'R N S Institute of Technology, Dr. Vishnuvardhana Road, R R Nagar Post, Channasandra, Bangalore - 56', 1966, 'VTU', 'http://www.rnsit.ac.in/'),
('R.V.COLLEGE OF ENGINEERING', 'RV', '080-28600184	', 'R V College of Engineering\r\nR V Vidyanikethan Post\r\nMysuru Road Bengaluru - 560 059', 1963, 'AUTONOMOUS', 'https://www.rvce.edu.in//');

-- --------------------------------------------------------

--
-- Table structure for table `cutoff`
--

CREATE TABLE `cutoff` (
  `COLLEGE_ID` varchar(10) NOT NULL,
  `COLLEGE_NAME` varchar(50) NOT NULL,
  `CUTOFF_CS` int(10) NOT NULL,
  `CUTOFF_IS` int(10) NOT NULL,
  `CUTOFF_EC` int(10) NOT NULL,
  `CUTOFF_ME` int(10) NOT NULL,
  `CUTOFF_CV` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cutoff`
--

INSERT INTO `cutoff` (`COLLEGE_ID`, `COLLEGE_NAME`, `CUTOFF_CS`, `CUTOFF_IS`, `CUTOFF_EC`, `CUTOFF_ME`, `CUTOFF_CV`) VALUES
('AY', 'ACHARAYA INSTITUTE OF TECHNOLOGY', 22063, 42193, 50492, 38342, 51664),
('BI', 'BANGALORE INSTITUTE OF TECHNOLOGY', 4086, 5763, 10280, 26315, 45904),
('BM', 'BMS COLLEGE OF ENGINEERING', 967, 1476, 1852, 4765, 18925),
('CR', 'C.M.R INSTITUTE OF TECHNOLOGY', 14959, 34469, 52111, 58129, 33129),
('GA', 'GLOBAL ACADEMY OF TECHNOLOGY', 40923, 40521, 43059, 45472, 44875),
('JS', 'JSS ACADEMY OF TECHNICIAL EDUCATION', 15056, 26539, 55037, 39999, 34251),
('KS', 'K.S.INSTITUTE OF TECHNOLOGY', 41864, 51864, 60110, 71810, 65110),
('MS', 'M.S.RAMAIAH INSTITUTE OF TECHNIOLOGY', 1145, 1922, 2225, 7092, 1527),
('RV', 'R.V.COLLEGE OF ENGINEERING', 373, 597, 856, 2111, 8674),
('RN', 'RNS INSTITUTE OF TECHNOLOGY', 9972, 16805, 22792, 51920, 56959),
('JB', 'SJB INSTITUTE OF TECHNOLOGY', 22448, 51876, 57730, 38033, 55242);

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE `fee` (
  `COLLEGE_ID` varchar(20) NOT NULL,
  `TUITION_FEE` varchar(11) NOT NULL,
  `BOYS_HOSTEL_FEE` varchar(11) NOT NULL,
  `GIRLS_HOSTEL_FEE` varchar(11) NOT NULL,
  `MESS_FEE` varchar(11) NOT NULL,
  `SEAT_IN_CS` int(11) NOT NULL,
  `SEAT_IN_IS` int(11) NOT NULL,
  `SEAT_IN_EC` int(11) NOT NULL,
  `SEAT_IN_ME` int(11) NOT NULL,
  `SEAT_IN_CV` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`COLLEGE_ID`, `TUITION_FEE`, `BOYS_HOSTEL_FEE`, `GIRLS_HOSTEL_FEE`, `MESS_FEE`, `SEAT_IN_CS`, `SEAT_IN_IS`, `SEAT_IN_EC`, `SEAT_IN_ME`, `SEAT_IN_CV`) VALUES
('AY', '1,83,600', '69,000', '69,000', '35,000', 36, 36, 36, 36, 36),
('BI', '1,83,600', '69,000', '69,000', '35,000', 49, 16, 49, 49, 49),
('BM', '1,83,600', '71,000', '71,000', '37,000', 33, 33, 33, 33, 33),
('CR', '1,83,600', '69,000', '69,000', '35,000', 49, 49, 66, 33, 33),
('GA', '1,30,380', '70,000', '70,000', '35,000', 49, 16, 49, 14, 14),
('JB', '1,83,600', '76,000', '76,000', '36,000', 49, 33, 25, 42, 51),
('JS', '1,83,600', '60,600', '60,600', '37,000', 49, 33, 49, 49, 33),
('KS', '1,30,680', '47,000', '47,000', '35,500', 33, 0, 33, 33, 0),
('MS', '1,83,600', '82,000', '82,000', '42,000', 33, 33, 33, 49, 33),
('RN', '1,83,600', '60,600', '60,600', '37,000', 33, 33, 49, 57, 21),
('RV', '1,83,600', '75,000', '75,000', '37,500', 49, 16, 49, 33, 33);

-- --------------------------------------------------------

--
-- Table structure for table `pref`
--

CREATE TABLE `pref` (
  `NAME` varchar(20) NOT NULL,
  `MARKS` int(10) NOT NULL,
  `RANK` int(10) NOT NULL,
  `COLLEGE` varchar(30) NOT NULL,
  `BRANCH` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sign_in`
--

CREATE TABLE `sign_in` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `Name` varchar(30) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(11) NOT NULL,
  `roll_no` int(11) NOT NULL,
  `rank` int(10) NOT NULL,
  `marks` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `repeat_password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college_details`
--
ALTER TABLE `college_details`
  ADD PRIMARY KEY (`COLLEGE_ID`);

--
-- Indexes for table `cutoff`
--
ALTER TABLE `cutoff`
  ADD KEY `GHG` (`COLLEGE_ID`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD KEY `aa` (`COLLEGE_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cutoff`
--
ALTER TABLE `cutoff`
  ADD CONSTRAINT `GHG` FOREIGN KEY (`COLLEGE_ID`) REFERENCES `college_details` (`COLLEGE_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `fee`
--
ALTER TABLE `fee`
  ADD CONSTRAINT `aa` FOREIGN KEY (`COLLEGE_ID`) REFERENCES `college_details` (`COLLEGE_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

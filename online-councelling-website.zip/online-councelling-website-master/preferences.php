<?php 
$name= filter_input(INPUT_POST, "name");
$mark= filter_input(INPUT_POST, "marks");
$rank= filter_input(INPUT_POST, "rank");
$col1= filter_input(INPUT_POST, "col1");
$col2= filter_input(INPUT_POST, "col2");
$col3= filter_input(INPUT_POST, "col3");
$br1= filter_input(INPUT_POST, "br1");
$br2= filter_input(INPUT_POST, "br2");
$br3= filter_input(INPUT_POST, "br3");
include("conn.php");
$sql1=mysqli_query($conn,"select $br1 from cutoff where COLLEGE_NAME='$col1'");
$sql2=mysqli_query($conn,"select $br2 from cutoff where COLLEGE_NAME='$col2'");
$sql3=mysqli_query($conn,"select $br3 from cutoff where COLLEGE_NAME='$col3'");
$row1=mysqli_fetch_assoc($sql1);
$row2=mysqli_fetch_assoc($sql2);
$row3=mysqli_fetch_assoc($sql3);

if($rank<$sql1){
	$ro1=mysqli_query($conn,"INSERT INTO pref VALUES ('$name','$mark','$rank','$col1','$br1')");
	echo "<pre>you are selected for $col1</pre>";

}
else if($rank>$row2){

$ro2=mysqli_query($conn,"INSERT INTO pref VALUES ('$name','$mark','$rank','$col2','$br2')");
echo "you are selected for $col2";
}
else if($rank>$row3){
$ro3=mysqli_query($conn,"INSERT INTO pref VALUES ('$name','$mark','$rank','$col3','$br3')");
echo "you are selected for $col3";
}
else{
	echo "No college select for your rank "."<br>";
	echo "!!!better luck next time!!!";
}


 ?>
<?php 
$name= filter_input(INPUT_POST, "name");
$pass= filter_input(INPUT_POST, "pass");
include("conn.php");
$sql=mysqli_query($conn,"select * from sign_up where Name='$name' and password='$pass'");
$row=mysqli_num_rows($sql);
if($row>0){
	$sql2=mysqli_query($conn,"INSERT INTO sign_in (username,password) VALUES('$name','$pass')");
	header("Location:home.html");
}
else{
	echo "check username or password";
}


 ?>